# Backlog de PURE · microcare · validado el 04-11-2026 · exportado desde Concilia el 04-11-2026 a las 09:41
@EP-04
Feature: Claim intake, treatment and verification
  Receive and reconcile forms, capture claims and clinical details, validate visits, and verify provider events.

  @HU-016 @RF-061 @RF-062 @RF-063 @RF-064 @RF-065 @RF-066 @RF-067
  Rule: Receive, reconcile and screen provider forms
    Como an authorized user, quiero record provider submissions and process received or corrected treatment forms, para investigate discrepancies and retain rejection history before claims become payable.
    Tarea T-035: Implement submission counts, discrepancy holds and printable receipts
    Tarea T-036: Implement form receipt logging, rejection reasons and quarantine exclusion
    Tarea T-037: Implement corrected-form resubmission with retained rejection history

    @CA-050
    Scenario: Receive and check form numbers
      Given a provider supplies a summary claims form and treatment forms
      When the submission is recorded
      Then the provider, current submission date, numeric stated and physically received form counts and each received form number are stored and the number of listed forms is checked against the physically received count

    @CA-051
    Scenario: Receive a mismatched submission
      Given the stated count differs from the physically received count
      When the submission is received
      Then receipt is allowed with a documented discrepancy and affected claims cannot be accepted or paid until missing or extra forms are investigated

    @CA-052
    Scenario: Print receipt
      Given a claim submission has been recorded
      When the receipt is produced
      Then it can be printed with provider, submission date and time, stated and received counts and individual treatment-form numbers

    @CA-053
    Scenario: Log form receipt
      Given a treatment form is received
      When it is logged for processing
      Then its paper form number is associated with its provider submission before entry as a claim

    @CA-054
    Scenario: Reject and quarantine a form
      Given a logged form is incomplete or apparently false
      When it is screened
      Then the submission is marked rejected and quarantined with a reason, no claim from it is accepted and any unaccepted claim is excluded from payable claims

    @CA-055
    Scenario: Resubmit a rejected form
      Given a treatment form was rejected and has been corrected
      When an authorized reviewer processes it in the following month's batch under the same form number
      Then the new submission and previous rejection are retained and payment remains excluded until the claim is accepted

  @HU-017 @RF-068 @RF-069 @RF-070 @RF-071
  Rule: Enter a received claim's header
    Como an authorized user, quiero enter a received form's identifiable claim header using maintained selections, para provide complete claim information for acceptance checks.
    Tarea T-038: Implement claim-number generation, populated receipt fields and conditional header validation
    Tarea T-039: Implement claim-entry selections backed by maintained records

    @CA-056
    Scenario: Start a received claim
      Given a received form number has not yet been entered for its submission
      When the user selects it for claim entry
      Then a claim number with an eight-digit number and hospital-code suffix is generated and the provider and submission date are populated from the form receipt

    @CA-057
    Scenario: Capture claim header
      Given a received form is entered as a claim
      When the user records the header
      Then form and claim numbers, submission and treatment dates, provider, voucher number, visit and patient types, patient name, age, gender, address, optional contact number, doctor, conditional doctor's notes and HIV details, patient status, calculated claim amount and claim status are captured

    @CA-058
    Scenario: Reject incomplete header for acceptance
      Given a required header field is missing
      When claim acceptance is attempted
      Then acceptance is prevented; contact number is optional, doctor's notes are required only when clinically indicated and HIV details only when information exists, with HIV-specific fields, allowed values and validation [TBD] pending the client's form

    @CA-059
    Scenario: Claim dropdown values
      Given a claim is being entered
      When the user opens relevant selections
      Then patient profiles, medicine costs, male or female gender, maintainable addresses and doctors from that provider's staff records are offered

  @HU-018 @RF-072 @RF-074
  Rule: Maintain clinical masters and treatment matrix
    Como an authorized user, quiero maintain clinical selection values and the syndrome-and-visit treatment matrix, para guide claim entry and record justified treatment deviations.
    Tarea T-040: Implement selectable clinical, status and reason masters
    Tarea T-041: Implement syndrome-and-visit matrix maintenance and deviation-justification recording
    Tarea T-042: Support deviation justification and test matrix validation

    @CA-060
    Scenario: Select reference values
      Given clinical or claim values need to be selected
      When the user maintains the selectable masters
      Then syndromes, clinical examinations, diagnoses, laboratory tests, other measures, patient statuses, claim statuses, referral reasons and claim quarantine or rejection reasons are available

    @CA-061
    Scenario: Approved matrix
      Given TA-OBA treatment guidance is maintained
      When the matrix is recorded by syndrome and visit
      Then its clinical content remains [TBD] pending the approved matrix

    @CA-062
    Scenario: Deviating claim
      Given a claim departs from the treatment matrix
      When the claim and its justification are assessed
      Then deviation does not itself prevent acceptance and the justification is recorded under [TBD] permitted-deviation and justification rules

  @HU-019 @RF-075
  Rule: Capture initial-consultation details
    Como an authorized user, quiero record the matrix-supported clinical details of an initial consultation, para document the first treatment visit for its claim.
    Tarea T-043: Implement matrix-supported initial-consultation clinical entry

    @CA-063
    Scenario: Initial visit clinical details
      Given an initial-consultation claim is entered
      When the user enters details supported by the approved matrix
      Then syndrome, clinical examination, diagnosis, laboratory test, drug name, frequency, number of days, quantity and other measures can be recorded

  @HU-020 @RF-076
  Rule: Capture follow-up clinical details
    Como an authorized user, quiero record clinical details permitted for a follow-up by syndrome and visit, para document follow-up claims without requiring unsupported fields.
    Tarea T-044: Implement matrix-supported follow-up entry and per-visit required fields

    @CA-064
    Scenario: Follow-up fields
      Given a follow-up claim is being entered
      When the user records diagnosis and drug name, frequency, days and quantity or matrix-supported multiple syndromes, examinations, laboratory tests, drugs and other measures
      Then those details are available and only fields specified for the syndrome and visit are required

  @HU-021 @RF-016 @RF-077 @RF-078 @RF-079 @RF-080 @RF-081 @RF-082 @RI-001
  Rule: Scan and validate voucher visits and claims
    Como an authorized user, quiero verify scanned visits, visit order and unique payable-claim eligibility, para prevent ineligible, repeated and duplicate payable claims.
    Tarea T-045: Integrate barcode reader capture and implement per-patient visit sequence checks
    Tarea T-046: Implement voucher eligibility, quarantine and unique payable-claim checks
    Tarea T-047: Test duplicate, out-of-order and TBD follow-up conditions

    @CA-065
    Scenario: Read visit slip
      Given a voucher visit slip is scanned for claim entry or voucher verification
      When the barcode reader supplies its contents
      Then the voucher number, client or partner patient type and visit type are captured for the shared voucher

    @CA-066
    Scenario: Limit ordered visits
      Given client and partner visits are tracked separately under one voucher number
      When a visit claim is evaluated
      Then one initial consultation and at most two ordered follow-ups per patient type are supported; a repeat or out-of-order visit claim is rejected

    @CA-067
    Scenario: Follow-up conditions
      Given a follow-up visit is being validated
      When its timing and provider are assessed
      Then [TBD] follow-up interval and provider-change rules apply

    @CA-068
    Scenario: Eligible claim
      Given a voucher was sold, not returned or withheld, valid on the treatment date and has no accepted claim for the same patient type and visit
      When its treatment claim is assessed
      Then it can be accepted subject to the other claim checks; the payable claim is identified by voucher number, patient type and visit, distinct from the paper treatment-form number

    @CA-069
    Scenario: Quarantine other eligibility failures
      Given a claim has an unsold, returned, withheld or treatment-date-invalid voucher or another non-paid-duplicate eligibility failure
      When claim acceptance is assessed
      Then acceptance is prevented and the claim is quarantined for review, including when expiry prohibits acceptance

    @CA-070
    Scenario: Prevent duplicate payment or acceptance
      Given a claim already exists for the same voucher, patient type and visit
      When another is submitted
      Then a second accepted claim is prevented and a duplicate of an already paid claim is rejected

  @HU-022 @RF-083 @RF-084
  Rule: Record treatment referrals
    Como an authorized user, quiero record a claim's referral destination and reason, para document out-of-network referrals without reimbursing their treatment.
    Tarea T-048: Implement referral capture and out-of-network reimbursement exclusion

    @CA-071
    Scenario: Claim referral
      Given a treatment claim records a referral
      When the referral is entered
      Then its destination and a reason selected from the referral-reason master are captured

    @CA-072
    Scenario: Out-of-network referral
      Given the destination is outside the approved provider network
      When the referral is recorded
      Then its name, location and reason are required and treatment by that destination is excluded from voucher reimbursement

  @HU-023 @RF-047 @RF-057 @RF-085 @RF-086
  Rule: Calculate treatment-claim amounts
    Como an authorized user, quiero calculate a claim using the authoritative matrix and effective contracted rates, para determine its payable amount and first-visit laboratory fee.
    Tarea T-049: Implement matrix-authoritative claim calculation and one-fee initial-visit lab rule
    Tarea T-050: Test initial laboratory fee and out-of-network exclusion

    @CA-073
    Scenario: Matrix governs calculation
      Given a claim has a treatment date, effective provider fees and drug prices and an approved matrix amount
      When the claim amount is calculated
      Then the matrix governs if its amount conflicts with the fee-and-price formula; consultation, laboratory and drug component calculations and discrepancy effects remain [TBD], with whole [TBD] currency units and [TBD] per-item rounding

    @CA-074
    Scenario: One laboratory fee for performed tests
      Given an initial-consultation claim has zero, one or several laboratory tests actually performed
      When its laboratory fee is calculated using the treatment-date-effective contracted fee
      Then zero tests earn no laboratory fee and one or more tests earn one contracted laboratory fee

  @HU-024 @RF-055 @RF-087 @RF-088 @RF-089 @RF-090 @RF-091 @RF-092 @RI-002
  Rule: Verify thumbprints and track provider events
    Como an authorized user, quiero verify claim thumbprints and record confirmed provider events, para hold unverifiable claims and inactivate providers above the event threshold.
    Tarea T-051: Integrate thumbprint reader and implement comparison and unavailable-check hold
    Tarea T-052: Implement all-time event counts, provider inactivation and mismatch warning

    @CA-075
    Scenario: Read and compare a print
      Given a paper treatment claim includes a patient's thumbprint
      When the thumbprint reader is used for claim-form verification
      Then the claim print is captured and compared with prior prints for that voucher and patient type by a [TBD] paper-print digitization and comparison procedure

    @CA-076
    Scenario: Identity check unavailable
      Given the claim print is unreadable, an earlier print is absent or the thumbprint reader is unavailable
      When claim verification is attempted
      Then the claim is placed on hold, with exception approver, evidence and audit record [TBD]

    @CA-077
    Scenario: Count confirmed events
      Given a thumbprint mismatch for a voucher and patient type is confirmed or a confirmed claim irregularity is in a [TBD] fraud-event category
      When the event is recorded
      Then it contributes to the provider's all-time combined event total

    @CA-078
    Scenario: Threshold and warning
      Given a provider's all-time combined total of counted fraud events and thumbprint mismatches exceeds two
      When the threshold is reached
      Then the provider is automatically inactivated and the system should be able to warn when counted thumbprint mismatches exceed two

    @CA-079
    Scenario: Claim for earlier treatment
      Given a provider has been inactivated
      When a claim is submitted for treatment completed before inactivation
      Then the submission is permitted

  @HU-025 @RF-093
  Rule: Amend claim information
    Como an authorized user, quiero amend entered claim information when permitted, para correct claim details under the defined authority and lifecycle rules.
    Tarea T-053: Implement authorized claim amendment
    Tarea T-054: Test claim amendment

    @CA-080
    Scenario: Authorized amendment
      Given a claim has been entered
      When an authorized user amends its information
      Then the claim information is amended, with correction authority and post-finalization rules [TBD]
