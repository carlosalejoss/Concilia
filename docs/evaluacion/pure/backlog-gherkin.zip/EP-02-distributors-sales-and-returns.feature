# Backlog de PURE · microcare · validado el 04-11-2026 · exportado desde Concilia el 04-11-2026 a las 09:41
@EP-02
Feature: Distributors, sales and returns
  Track pilot distributors and salespeople, wholesale allocations, retail sales and voucher returns.

  @HU-005 @RF-019 @RF-020 @RF-021 @RF-022 @RF-023 @RF-024 @RF-025 @RF-026
  Rule: Maintain distributors and their history
    Como a permitted user, quiero maintain distributor records and inspect their voucher histories, para manage and trace the pilot distribution network.
    Tarea T-012: Implement distributor records, geographic addresses and creation checks
    Tarea T-013: Implement distributor maintenance, history and child-record deletion check
    Tarea T-014: Test distributor duplicate, child-record and history cases

    @CA-015
    Scenario: Create a distributor
      Given a distributor has a unique code, name, business type, proprietor name and geographical address
      When the user saves the distributor
      Then its designation, contact number, email and active or deactivated status can be recorded and its district, sub-district, county, sub-county, village or town and street or road address values can be maintained

    @CA-016
    Scenario: Reject missing information or a duplicate code
      Given a new distributor lacks a code, name, business type, proprietor name or address or reuses an existing code
      When the user attempts to create it
      Then creation is rejected

    @CA-017
    Scenario: Warn about a duplicate name
      Given a distributor name already exists
      When another distributor is entered under that name
      Then the user is warned and may save the duplicate name or change it

    @CA-018
    Scenario: Manage distributor and history
      Given the user is permitted to access a selected distributor
      When the user adds, edits, activates, deactivates, views or prints its record or views or prints its history
      Then the permitted action is available and the history shows batch number, purchase date, quantities purchased, sold and returned, and remaining balance

    @CA-019
    Scenario: Keep a distributor with child records
      Given a distributor has child records
      When a user attempts to delete it
      Then deletion is rejected

  @HU-006 @RF-027 @RF-028 @RF-029 @RF-030
  Rule: Maintain individual pilot salespeople
    Como an authorized user, quiero maintain individual MSIU salesperson records, para attribute pilot sales without a country-wide sales-team master.
    Tarea T-015: Implement pilot salesperson records and uniqueness and completeness checks
    Tarea T-016: Test salesperson creation and duplicate handling

    @CA-020
    Scenario: Record an individual salesperson
      Given a pilot salesperson is entered
      When the record is saved
      Then it stores code, name, birth date, age, gender, communication address, contact number and email without requiring a future country-wide sales-team master

    @CA-021
    Scenario: Reject missing fields or reused code
      Given the salesperson lacks code, name, birth date, age, gender or communication address or their code already exists
      When creation is attempted
      Then creation is rejected

    @CA-022
    Scenario: Warn about an existing name
      Given another salesperson has the same name
      When the user enters that name
      Then the user is warned and may retain or change the name

  @HU-007 @RF-031 @RF-047
  Rule: Maintain wholesale rate and monetary rules
    Como an authorized user, quiero maintain the voucher wholesale rate and apply whole-unit monetary rules, para make distribution invoices and other recorded amounts consistent.
    Tarea T-017: Implement wholesale-rate maintenance and shared whole-unit per-item monetary handling

    @CA-023
    Scenario: Maintain wholesale rate
      Given a wholesale voucher rate is needed for distribution invoices
      When the user maintains the rate
      Then the rate is available for invoice calculations

    @CA-024
    Scenario: Apply monetary representation
      Given voucher prices, sales, returns, drug prices or claim amounts are recorded
      When a monetary item is stored or calculated
      Then it uses whole [TBD] currency units with [TBD] rounding applied per item

  @HU-008 @RF-031 @RF-032 @RF-033 @RF-034 @RF-035 @RF-036
  Rule: Allocate and invoice distributor vouchers
    Como an authorized user, quiero allocate eligible vouchers through a salesperson and generate the distributor invoice, para trace wholesale stock and charge the applicable rate.
    Tarea T-018: Implement ordered eligible-stock allocation and atomic distribution validation
    Tarea T-019: Implement numbered distribution invoices using the applicable wholesale rate
    Tarea T-020: Test ordered allocation and all-or-nothing stock rejection

    @CA-025
    Scenario: Allocate eligible stock
      Given a distributor requests a quantity of vouchers and sufficient eligible stock exists
      When the distribution is recorded
      Then unassigned, unexpired and non-withheld vouchers are allocated in ascending voucher-number order and their batch and voucher numbers and validity dates are shown with the distributor, salesperson, quantity, cash payment mode and current-system-date distribution

    @CA-026
    Scenario: Insufficient stock
      Given fewer eligible vouchers exist than the quantity requested
      When the distribution is submitted
      Then the entire request is rejected with no partial allocation

    @CA-027
    Scenario: Distribution date
      Given a user records a distribution
      When its date is set or a future distribution date is attempted
      Then the distribution date is the current system date and a future date is rejected

    @CA-028
    Scenario: Invoice calculation
      Given a distribution allocates vouchers at a wholesale rate applicable on its distribution date
      When the distribution is recorded
      Then an invoice number is generated and its amount is the allocated voucher quantity multiplied by that rate

  @HU-009 @RF-016 @RF-037 @RF-038 @RF-039 @RF-040 @RF-041
  Rule: Record individual retail sales
    Como an authorized VMU user, quiero record each distributor-supplied retail sale against one voucher, para trace actual customers and amounts and derive sales totals.
    Tarea T-021: Implement per-voucher retail sales, derived totals and sale validations

    @CA-029
    Scenario: Enter a retail sale
      Given the distributor supplies details of a sale
      When an authorized VMU user enters it
      Then one voucher number, the supplying distributor, customer name and living address, actual sale date, place and actual amount paid are recorded; the fixed approved retail price is used and totals derive from individual sales

    @CA-030
    Scenario: Reject multiple vouchers
      Given one customer is buying more than one voucher at one time
      When the sale transaction is submitted
      Then the transaction is rejected

    @CA-031
    Scenario: Validate sale date and expiry
      Given a sale is being entered for a voucher
      When the actual date is in the past, in the future or the voucher has expired at sale
      Then a past actual date is permitted while a future date or a sale of an expired voucher is rejected

    @CA-032
    Scenario: Enforce printed maximum
      Given the voucher has a printed maximum retail price
      When the actual amount paid exceeds that price
      Then the retail sale is rejected

  @HU-010 @RF-042
  Rule: Inspect distribution and sales breakdowns
    Como a permitted user, quiero view distribution and sales information by distributor, salesperson and batch, para follow voucher movement and pilot retail activity.
    Tarea T-022: Implement distributor, salesperson and batch distribution and sales breakdowns

    @CA-033
    Scenario: Break down transactions
      Given distributions and individual sales have been recorded
      When the user requests distribution and sales information
      Then the information is available distributor-wise, individual-salesperson-wise and batch-wise

  @HU-011 @RF-043 @RF-044 @RF-045 @RF-046 @RF-047
  Rule: Process distributor voucher returns
    Como an authorized user, quiero record eligible unsold voucher returns and calculate refunds, para restore saleable stock at the original invoiced wholesale rate.
    Tarea T-023: Implement return recording, eligibility checks, stock restoration and original-rate refunds
    Tarea T-024: Test return date, monetary precision and rejection rules

    @CA-034
    Scenario: Accept eligible returns
      Given unsold and unused vouchers belong to the returning distributor
      When a return is recorded
      Then the distributor, salesperson, default current-system-date return date, quantity, amount and each batch and voucher number are captured; returned vouchers become saleable stock and the refund uses the originally invoiced wholesale rate in whole [TBD] currency units with [TBD] rounding per item

    @CA-035
    Scenario: Reject ineligible vouchers
      Given a voucher was not distributed to the returning distributor or was sold or used
      When its return is attempted
      Then that return is rejected

    @CA-036
    Scenario: Reject future return date
      Given a distributor return is being entered
      When its date is in the future
      Then the date is rejected
