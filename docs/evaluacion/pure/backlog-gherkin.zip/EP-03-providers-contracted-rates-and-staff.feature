# Backlog de PURE · microcare · validado el 04-11-2026 · exportado desde Concilia el 04-11-2026 a las 09:41
@EP-03
Feature: Providers, contracted rates and staff
  Maintain the approved provider network, payment terms, drug prices, staff and provider-claim history.

  @HU-012 @RF-048 @RF-049 @RF-050 @RF-051 @RF-052 @RF-053 @RF-054 @RF-055
  Rule: Maintain approved pilot providers
    Como a permitted user, quiero maintain approved Mbarara providers and their activation status, para keep the eligible network current while allowing claims for earlier treatments.
    Tarea T-025: Implement approved-provider records, generated codes and creation checks
    Tarea T-026: Implement provider maintenance, active-entry filtering and earlier-treatment exception
    Tarea T-027: Test provider selection and claims for earlier treatments

    @CA-037
    Scenario: Create approved provider
      Given a private, NGO, faith-based or government-hospital Mbarara provider is approved
      When the user creates its record
      Then a numeric code with the SP suffix is generated and its name, physical and communication addresses, health sub-district, locality, facility level and type, registration body, contact person, designation, optional contact number and email, and active or inactive status are maintained

    @CA-038
    Scenario: Required fields and duplicate name
      Given a new provider lacks a master field other than contact number or email or its name already exists
      When creation is attempted
      Then missing required fields prevent creation, while a duplicate name produces a warning and is saved only after user confirmation

    @CA-039
    Scenario: Maintain and list providers
      Given a permitted user maintains provider records and payment terms according to MSIU management decisions
      When the user adds, amends, deletes or changes activation status or selects providers for new entry or reports
      Then the permitted maintenance action is available, new-entry choices list active providers and reports can include active and inactive providers

    @CA-040
    Scenario: Previously completed treatment
      Given a provider became inactive after completing a treatment
      When a claim for that earlier treatment is submitted
      Then the claim can be submitted despite the provider's current inactive status

  @HU-013 @RF-047 @RF-054 @RF-056 @RF-057 @RF-073
  Rule: Maintain effective-dated fees and drug prices
    Como a permitted user, quiero maintain provider payment terms and shared reimbursable drug prices, para apply treatment-date rates and recalculate affected accepted claims.
    Tarea T-028: Implement provider payment terms and fee maintenance
    Tarea T-029: Implement effective-period checks, treatment-date lookups and accepted-claim recalculation
    Tarea T-030: Implement drug master, shared effective-dated prices and rate-change handling
    Tarea T-031: Test effective-rate selection and provider-independent drug pricing

    @CA-041
    Scenario: Record terms
      Given a provider's payment terms are maintained
      When the user records them
      Then cash or bank-transfer mode, bank name and account, monthly or twice-per-calendar-month frequency, and effective-dated numeric initial-consultation, first-follow-up, second-follow-up and initial-visit laboratory fees are maintained with fee defaults of zero

    @CA-042
    Scenario: Maintain contracted terms
      Given a permitted user manages a provider's payment terms
      When the user adds, amends or deletes those terms
      Then the corresponding permitted terms-maintenance action is available

    @CA-043
    Scenario: Rate effective date
      Given provider fees and drug prices have effective periods
      When rates are maintained or applied to a claim
      Then overlapping periods are rejected and the rates effective on the treatment date are selected

    @CA-044
    Scenario: Retrospective rate change
      Given a rate change affects an accepted claim's treatment date
      When the change is made retrospectively
      Then the affected accepted claim is recalculated

    @CA-045
    Scenario: Maintain drug prices
      Given a drug is recorded
      When its generic name, code, name and treatment-date-effective reimbursable retail price are maintained
      Then one price per drug applies to all providers and monetary values use whole [TBD] currency units and [TBD] per-item rounding

    @CA-046
    Scenario: Drug price period change
      Given a drug has an effective price period
      When a proposed period overlaps or an earlier price is changed
      Then overlaps are rejected and affected accepted claims are recalculated after retrospective changes

  @HU-014 @RF-058
  Rule: View a provider's claim history
    Como a permitted user, quiero view a selected provider's claims and their statuses, para inspect recorded claim amounts and remarks.
    Tarea T-032: Implement selected-provider claim history retrieval

    @CA-047
    Scenario: Provider claims
      Given a provider has recorded claims
      When the user selects that provider's claim history
      Then claim number, claim date, system-entry date, amount, status and remarks are available

  @HU-015 @RF-059 @RF-060
  Rule: Register provider staff
    Como a permitted user, quiero register a provider's staff and generated staff code, para associate doctors and other staff with their provider.
    Tarea T-033: Implement provider-staff records, generated codes and duplicate-name warnings
    Tarea T-034: Test staff duplicate handling and claim history fields

    @CA-048
    Scenario: Create provider staff
      Given a staff member is entered for a provider
      When the record is created
      Then provider, staff name, staff type and optional qualification are stored and a code is generated from provider code, SC and a numeric suffix of [TBD] length

    @CA-049
    Scenario: Duplicate staff name
      Given a provider staff name already exists
      When another staff record with that name is entered
      Then the user is warned and may save the new staff record
