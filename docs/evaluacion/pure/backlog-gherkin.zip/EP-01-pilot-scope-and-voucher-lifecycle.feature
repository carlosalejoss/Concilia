# Backlog de PURE · microcare · validado el 04-11-2026 · exportado desde Concilia el 04-11-2026 a las 09:41
@EP-01
Feature: Pilot scope and voucher lifecycle
  Support the Mbarara pilot, create and print vouchers, and control their validity and withholding.

  @HU-001 @RF-001 @RF-002
  Rule: Configure pilot scope and later growth
    Como an authorized user, quiero configure the Mbarara pilot and allow subsequent geographic and voucher-volume growth, para operate the first release without requiring country-wide sales-team management.
    Tarea T-001: Configure pilot scope and voucher tracking
    Tarea T-002: Test pilot capacity scope and later-growth configuration

    @CA-001
    Scenario: Pilot scope
      Given the system is configured for the first release
      When the pilot is operated
      Then it supports the one-year Mbarara pilot and anticipated sales of 20,000 vouchers, including distributor and individual-salesperson tracking

    @CA-002
    Scenario: Later growth
      Given the pilot configuration is in use
      When geographic coverage or voucher volume grows
      Then the system supports growth beyond the Mbarara pilot; country-wide sales-team management is not part of this capability

  @HU-002 @RF-001 @RF-003 @RF-004 @RF-005 @RF-006 @RF-007 @RF-008
  Rule: Create coded voucher runs
    Como an authorized user, quiero create uniquely coded vouchers in fixed batches subject to a configurable run minimum, para prepare identifiable voucher stock for the pilot.
    Tarea T-003: Implement pilot voucher creation and provision for later geographic and volume growth
    Tarea T-004: Implement code assignment and fixed group-batch and batch structure
    Tarea T-005: Implement minimum-quantity configuration and creation validation
    Tarea T-006: Test code patterns, batch quantities and minimum enforcement

    @CA-003
    Scenario: Pilot creation
      Given an authorized user is creating vouchers for the one-year Mbarara pilot
      When the creation is completed
      Then the vouchers are available to support the pilot's anticipated sale of 20,000 vouchers

    @CA-004
    Scenario: Coded voucher creation
      Given vouchers are being created
      When the system assigns identifiers
      Then each voucher has a unique voucher number and project, group-batch, batch and security codes; project and group-batch codes follow the P001 and GP0001 patterns

    @CA-005
    Scenario: Batch structure and pending code specifications
      Given a creation run is being organized
      When the system forms group-batches and batches
      Then each group-batch contains exactly 100 batches and each batch contains exactly 10 vouchers; allowed characters, lengths and uniqueness scope of all codes and the other code formats remain [TBD]

    @CA-006
    Scenario: Set the minimum
      Given an authorized user maintains creation settings
      When the user sets the minimum voucher quantity per run
      Then the minimum is stored, with its initial value [TBD]

    @CA-007
    Scenario: Reject a short run
      Given a minimum quantity is configured
      When a creation request contains fewer vouchers than that minimum
      Then the entire creation request is rejected

  @HU-003 @RF-009 @RF-010 @RF-011 @RF-012
  Rule: Prepare printed vouchers and visit slips
    Como an authorized user, quiero prepare barcoded client and partner portions and their visit slips, para identify each person's three visits under one voucher number.
    Tarea T-007: Implement voucher print preparation and encoded visit-slip barcodes
    Tarea T-008: Test client and partner slip identification and price printing

    @CA-008
    Scenario: Shared voucher portions
      Given a voucher is being prepared for printing
      When its client and partner portions are produced
      Then they share one voucher number, have three separately identified slips each for initial consultation and two follow-ups, and display the stored maximum retail price

    @CA-009
    Scenario: Visit barcode content
      Given a client or partner visit slip is prepared
      When its barcode is rendered along with voucher codes as barcodes on the voucher
      Then the visit barcode encodes the shared voucher number, security code, patient type and initial-consultation, first-follow-up or second-follow-up visit type

  @HU-004 @RF-013 @RF-014 @RF-015 @RF-016 @RF-017 @RF-018
  Rule: Control voucher validity and withholding
    Como an authorized user, quiero amend voucher validity and withhold or release individual vouchers, para enforce voucher-use restrictions without changing other voucher details.
    Tarea T-009: Implement validity dates, amendments, expiry checks and voucher immutability
    Tarea T-010: Implement voucher withholding, release and configurable blocked-action validation
    Tarea T-011: Test amendments on sold vouchers and immutable voucher records

    @CA-010
    Scenario: Validity starts and is amendable
      Given a voucher is created with validity starting on its creation date and an expiry determined by [TBD]
      When an authorized user amends its validity date
      Then the amended date applies to that voucher even if it has already been sold

    @CA-011
    Scenario: Expiry prevents use
      Given a voucher is expired at retail sale or treatment or invalid on a claim's treatment date
      When a sale, treatment or claim acceptance is attempted respectively
      Then that sale or treatment is rejected or claim acceptance is rejected, respectively

    @CA-012
    Scenario: Other voucher changes are prohibited
      Given a voucher already exists
      When a user attempts to edit or delete it outside an authorized validity-date amendment or withholding-status change
      Then the change is rejected

    @CA-013
    Scenario: Change withholding status
      Given an individual voucher exists
      When an authorized user withholds it or subsequently releases it
      Then the voucher's withholding status reflects that action

    @CA-014
    Scenario: Reject an action blocked by withholding
      Given a voucher is withheld and the actions blocked by withholding are [TBD]
      When a blocked action is attempted
      Then the action is rejected rather than merely warned about
