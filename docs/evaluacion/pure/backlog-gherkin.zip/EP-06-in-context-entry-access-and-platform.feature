# Backlog de PURE · microcare · validado el 04-11-2026 · exportado desde Concilia el 04-11-2026 a las 09:41
@EP-06
Feature: In-context entry, access and platform
  Support master-value entry, user administration, permitted deletion, sensitive-data protection and system quality.

  @HU-030 @RF-099
  Rule: Add missing master values during entry
    Como an authorized user, quiero add an applicable missing master value without closing the active entry, para complete distribution, provider, provider-staff or claim records.
    Tarea T-065: Implement in-context master-value addition and resumption of active entry
    Tarea T-066: Test resumption of each supported active entry

    @CA-090
    Scenario: Resume active entry
      Given the user is entering a distribution, provider, provider-staff or claim record
      When a needed distributor, salesperson, geographic, facility or staff-type master value is missing
      Then the value can be added and the active entry resumes without being closed

  @HU-031 @RF-101 @RF-102 @RF-103 @RF-104 @RNF-003
  Rule: Create groups and users with screen permissions
    Como the system administrator, quiero create user groups and accounts with screen-action permissions, para control access to system records and actions.
    Tarea T-067: Implement administrator-only group creation and per-screen action enforcement
    Tarea T-068: Implement grouped user creation, matching-password and unique-name checks, and account-security rules when defined

    @CA-091
    Scenario: Administrator creates group
      Given a group code and unique group name are supplied
      When the system administrator creates a group
      Then per-screen new, edit, delete, view and print permissions are recorded; only the administrator can create groups

    @CA-092
    Scenario: Check group permission
      Given a user belongs to a group
      When the user requests a new, edit, delete, view or print screen action
      Then the group's permission applies, with group definitions and record-specific assignments [TBD]

    @CA-093
    Scenario: Create user
      Given a user group is selected
      When a user name, password and matching verification entry are provided
      Then the user can be created under that group

    @CA-094
    Scenario: Reject invalid or reused names
      Given the password and verification do not match or a proposed individual user or user-group name already exists
      When creation is attempted
      Then creation is rejected

    @CA-095
    Scenario: Pending account-security rules
      Given a user account is used
      When password strength, failed-login lockout, verified password reset or idle-session timeout applies
      Then password-strength requirements, failed-login threshold and duration, reset procedure and idle timeout remain [TBD]

  @HU-032 @RF-100 @RF-013
  Rule: Control non-voucher record deletion
    Como a permitted user, quiero delete entered non-voucher records when allowed, para correct records without allowing voucher deletion.
    Tarea T-069: Implement non-voucher deletion permission checks and voucher deletion prohibition
    Tarea T-070: Test deletion rules once defined

    @CA-096
    Scenario: Permitted non-voucher deletion
      Given an entered non-voucher record exists
      When a permitted user requests its deletion
      Then deletion is allowed under [TBD] record-type, user-group and post-finalization rules

    @CA-097
    Scenario: Voucher remains immutable
      Given the record to be deleted is an existing voucher
      When its deletion is attempted
      Then deletion is rejected

  @HU-033 @RNF-001 @RNF-002
  Rule: Protect sensitive information and printed reports
    Como a permitted user, quiero handle sensitive patient information under defined safeguards, para protect identity, HIV information and thumbprints in use and in reports.
    Tarea T-071: Mask sensitive fields in printed reports
    Tarea T-072: Implement TBD sensitive-data access, audit and retention controls
    Tarea T-073: Test report masking and sensitive-data controls

    @CA-098
    Scenario: Mask sensitive fields in printed reports
      Given a report containing patient identity, HIV information or thumbprints is printed
      When the report is rendered
      Then each of those sensitive detail types is masked

    @CA-099
    Scenario: Apply sensitive-data controls
      Given patient identity, HIV information or thumbprints are viewed, changed, retained or disposed of
      When the relevant operation occurs
      Then confidentiality and access restrictions, access-and-change audit logging, retention periods and disposal rules follow [TBD]

  @HU-034 @RF-001 @RF-002 @RNF-004 @RNF-005 @RNF-006 @RNF-007 @RNF-008 @RNF-009 @RT-001
  Rule: Operate on the required platform and quality targets
    Como the system administrator, quiero deploy the specified technology stack and assess pilot and expansion targets, para support voucher operations and reports as the system grows.
    Tarea T-074: Implement the specified database, front end and reporting stack and validate capacity against [TBD] targets when supplied
    Tarea T-075: Establish performance, availability and capacity tests against TBD targets
    Tarea T-076: Apply and verify TBD intrusion-control level

    @CA-100
    Scenario: Specified technology
      Given the system is delivered for the one-year Mbarara pilot and later expansion
      When voucher operations and reporting are run
      Then Oracle 9i is used for the database, Visual Basic for the front end and Crystal Reports 9 for reporting

    @CA-101
    Scenario: Pending pilot and expansion targets
      Given the pilot anticipates 20,000 voucher sales and geographic and volume growth is possible later
      When interactive response, standard-report generation, availability, concurrent users and daily and peak transaction capacity are assessed
      Then pilot and expansion response times are [TBD] seconds, report times [TBD] seconds, availability [TBD] percent, concurrent capacity [TBD] users, and daily and peak transaction volumes [TBD] for each phase

    @CA-102
    Scenario: Meet intrusion-control level
      Given the system is operated
      When intrusion controls are assessed
      Then the intrusion-control level is [TBD]
