# Backlog de PURE · microcare · validado el 04-11-2026 · exportado desde Concilia el 04-11-2026 a las 09:41
@EP-05
Feature: Payment reporting, feedback and programme reports
  Calculate payment information for MSIU, collect feedback and produce the specified standard reports.

  @HU-026 @RF-094 @RF-095 @RF-105 @RNF-001
  Rule: Prepare provider payment reports
    Como an authorized user, quiero calculate accepted claims and prepare payment information for MSIU, para support payment arrangements outside the system.
    Tarea T-055: Implement provider payment calculations, period-aware standard reports and print masking
    Tarea T-056: Test report output without initiating payments

    @CA-081
    Scenario: Financial and medical payment reporting
      Given accepted claims and provider monthly or twice-per-calendar-month terms are recorded
      When the user prepares financial and medical payment reports
      Then claims are calculated for MSIU without the system initiating payments; twice-per-calendar-month means two periods per calendar month, while submission and payment boundaries and cutoffs remain [TBD]

    @CA-082
    Scenario: Monthly claim categories and masking
      Given claims have been collected during a month
      When post-collection reports are produced and printed
      Then clean claims payable without reservation are distinguished from claims whose payment is withheld pending clarification and printed patient identity, HIV data and thumbprints are masked

  @HU-027 @RF-096 @RF-097 @RF-098
  Rule: Record feedback for a selected patient visit
    Como an authorized user, quiero associate feedback with one client or partner visit and record client responses, para retain feedback without altering claim treatment details.
    Tarea T-057: Implement feedback visit selection, claim-detail population and partner-treated derivation
    Tarea T-058: Implement client feedback responses and stated satisfaction choices

    @CA-083
    Scenario: Select feedback visit
      Given a voucher may have client and partner claims across visits
      When the user selects voucher number, client or partner patient type and a visit
      Then the feedback is associated with that selection and the corresponding claim supplies the patient address, treated syndromes, laboratory tests, drugs and referral

    @CA-084
    Scenario: Protect treatment details and derive partner status
      Given feedback has an associated claim
      When the user reviews its populated details
      Then those treatment details cannot be changed in feedback and partner-treated status is derived from an accepted partner claim

    @CA-085
    Scenario: Client feedback scales
      Given feedback from the client is being captured
      When treatment success and treatment, counseling and privacy satisfaction are entered
      Then success is reported by the client with response values [TBD] and each satisfaction response uses Not at all, Moderate, Good or Completely

  @HU-028 @RF-105 @RF-106 @RF-107 @RF-108 @RF-109 @RNF-001
  Rule: Produce standard claim and service reports
    Como a permitted user, quiero produce provider claim summaries and treatment and patient frequencies, para review the specified claim and service measures.
    Tarea T-059: Implement provider and quarterly claim summaries with masked printing
    Tarea T-060: Implement syndrome, demographic and client-partner frequency reports with print masking
    Tarea T-061: Test listed standard report outputs

    @CA-086
    Scenario: Provider and quarterly summaries
      Given provider claims exist
      When the user produces claim reports
      Then a claim report for each provider, a summary for all providers and quarterly summaries per provider and for all providers combined are available

    @CA-087
    Scenario: Printed claim summaries
      Given a claim or quarterly summary report is available
      When it is printed
      Then patient identity, HIV information and thumbprints are masked

    @CA-088
    Scenario: Frequency reports
      Given treatment and patient records are available
      When the user produces the standard frequency reports
      Then frequencies of treated syndromes, patient sex and age, primary clients and notified partners are reported and printed patient identity, HIV information and thumbprints are masked

  @HU-029 @RF-110 @RNF-001
  Rule: Report care quality and trends
    Como a permitted user, quiero compare clinical quality indicators across providers and over time, para review documentation and treatment performance using the pending indicator definitions.
    Tarea T-062: Implement defined indicator and trend reports once their [TBD] calculation rules are supplied
    Tarea T-063: Implement clinical quality report data structure
    Tarea T-064: Test standard clinical quality report outputs

    @CA-089
    Scenario: Indicator reports awaiting definitions
      Given the Programme Design Study, sources and indicator rules remain [TBD]
      When documentation quality, algorithm adherence, justified treatment alterations, treatment errors and provider comparisons and quarterly and half-yearly trends are reported
      Then results for individual providers and all providers use [TBD] sources, numerators, denominators, classification rules, periods and comparison methods, and patient identity, HIV data and thumbprints are masked when printed
